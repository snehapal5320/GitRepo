import java.rmi.*;

public class MyClient {
    public static void main(String args[]) {
        try {
            DateTime stub = (DateTime) Naming.lookup("DT");
            System.out.println(stub.date(2));
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}