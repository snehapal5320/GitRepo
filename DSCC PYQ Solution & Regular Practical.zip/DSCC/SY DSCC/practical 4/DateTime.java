import java.rmi.*;
public interface DateTime extends Remote{
public int date(int op)throws RemoteException;
}
