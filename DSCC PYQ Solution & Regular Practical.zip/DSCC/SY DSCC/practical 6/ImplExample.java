import java.sql.*;
import java.util.*;

// Implementing the remote interface
public class ImplExample implements Hello {

// Implementing the interface method
public List<Book> getBooks() throws Exception {
List<Book> list = new ArrayList<Book>();

// JDBC driver name and database URL
String JDBC_DRIVER = "com.mysql.jdbc.Driver";
String DB_URL = "jdbc:mysql://localhost:3307/details";

// Database credentials
String USER = "root";
String PASS = "";

Connection conn = null;
Statement stmt = null;

//Register JDBC driver
Class.forName("com.mysql.jdbc.Driver");

//Open a connection
System.out.println("Connecting to a selected database...");
conn = DriverManager.getConnection(DB_URL, USER, PASS);
System.out.println("Connected database successfully...");
//Execute a query
System.out.println("Creating statement...");
stmt = conn.createStatement();
String sql = "SELECT * FROM book_data";
ResultSet rs = stmt.executeQuery(sql);
while(rs.next()) {
// Retrieve by column name
int id = rs.getInt("id");
String name = rs.getString("name");
String author = rs.getString("author");
Book book= new Book();
book.setID(id);
book.setName(name);
book.setAuthor(author);
list.add(book);
}
rs.close();
return list;
}
}