public class Book implements java.io.Serializable 
{
private int id;
private String name, author;

public int getId() {
return id;
}
public String getName() {
return name;
}
public String getAuthor() {
return author;
}
public void setID(int id) {
this.id = id;
}
public void setName(String name) {
this.name = name;
}
public void setAuthor(String author) {
this.author= author;
}
}