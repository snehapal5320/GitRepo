import java.net.*;
import java.util.StringTokenizer;

public class RPCServer {
    DatagramSocket ds;
    DatagramPacket dp;
    String str, methodName, result;
    int val1, val2;

    RPCServer() {
        try {
            ds = new DatagramSocket(1200);
            byte[] b = new byte[4096];
            
            while (true) {
                dp = new DatagramPacket(b, b.length);
                ds.receive(dp);
                str = new String(dp.getData(), 0, dp.getLength());

                if (str.equalsIgnoreCase("q")) {
                    System.exit(1);
                } else {
                    StringTokenizer st = new StringTokenizer(str, " ");
                    if (st.hasMoreTokens()) {
                        methodName = st.nextToken();
                        if (st.hasMoreTokens()) {
                            val1 = Integer.parseInt(st.nextToken());
                        }
                        if (st.hasMoreTokens()) {
                            val2 = Integer.parseInt(st.nextToken());
                        }
                    }
                }

                System.out.println("Received: " + str);

                // Processing the method
                if (methodName.equalsIgnoreCase("add")) {
                    result = "" + add(val1, val2);
                } else if (methodName.equalsIgnoreCase("sub")) {
                    result = "" + sub(val1, val2);
                } else if (methodName.equalsIgnoreCase("mul")) {
                    result = "" + mul(val1, val2);
                } else if (methodName.equalsIgnoreCase("div")) {
                    if (val2 == 0) {
                        result = "Error: Division by zero";
                    } else {
                        result = "" + div(val1, val2);
                    }
                }

                byte[] b1 = result.getBytes();
                DatagramPacket dp1 = new DatagramPacket(b1, b1.length, dp.getAddress(), dp.getPort());
                System.out.println("Result: " + result + "\n");
                ds.send(dp1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int add(int val1, int val2) {
        return val1 + val2;
    }

    public int sub(int val1, int val2) {
        return val1 - val2;
    }

    public int mul(int val1, int val2) {
        return val1 * val2;
    }

    public int div(int val1, int val2) {
        return val1 / val2;
    }

    public static void main(String[] args) {
        new RPCServer();
    }
}
