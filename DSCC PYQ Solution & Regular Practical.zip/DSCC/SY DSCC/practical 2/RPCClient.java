import java.io.*;
import java.net.*;

public class RPCClient {
    RPCClient() {
        try {
            InetAddress ia = InetAddress.getLocalHost();
            DatagramSocket ds = new DatagramSocket();
            System.out.println("\nRPC Client\n");
            System.out.println("Enter method name and parameters like 'add 3 4' or 'q' to quit\n");

            while (true) {
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                String str = br.readLine();
                
                if (str.equalsIgnoreCase("q")) {
                    System.out.println("Exiting...");
                    break; // Exit the loop if "q" is entered
                }

                byte[] sendBuffer = str.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sendBuffer, sendBuffer.length, ia, 1200);
                ds.send(sendPacket);

                // Buffer for receiving the response
                byte[] receiveBuffer = new byte[4096];
                DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
                ds.receive(receivePacket);

                // Display the result
                String result = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("\nResult = " + result + "\n");
            }

            ds.close(); // Close the socket when finished
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new RPCClient();
    }
}
