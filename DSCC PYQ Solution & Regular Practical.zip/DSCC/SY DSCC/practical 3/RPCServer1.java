import java.util.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

class RPCServer1 {
    DatagramSocket ds;
    DatagramPacket dp;
    String str, methodName, result;

    RPCServer1() {
        try {
            ds = new DatagramSocket(1200);  // Server listens on port 1200
            byte[] b = new byte[4096];      // Buffer to receive incoming data

            while (true) {
                dp = new DatagramPacket(b, b.length);
                ds.receive(dp);             // Receive the packet
                str = new String(dp.getData(), 0, dp.getLength());  // Convert the packet to string

                if (str.equalsIgnoreCase("q")) {
                    System.out.println("Server shutting down...");
                    System.exit(1);         // Exit if "q" is received
                } else {
                    StringTokenizer st = new StringTokenizer(str, " ");
                    if (st.hasMoreTokens()) {
                        methodName = st.nextToken();  // Extract the method name from the input
                    }

                    Calendar c = Calendar.getInstance();
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                    Date d = c.getTime();
                    
                    if (methodName.equalsIgnoreCase("date")) {
                        result = "" + dateFormat.format(d);  // Return current date
                    } else if (methodName.equalsIgnoreCase("time")) {
                        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
                        result = timeFormat.format(d);       // Return current time
                    } else {
                        result = "Unknown method";           // Handle unknown methods
                    }

                    // Send the response back to the client
                    byte[] b1 = result.getBytes();
                    InetAddress clientAddress = dp.getAddress();  // Get client's address from received packet
                    int clientPort = dp.getPort();                // Get client's port from received packet
                    DatagramPacket dp1 = new DatagramPacket(b1, b1.length, clientAddress, clientPort);

                    System.out.println("Result: " + result + "\n");
                    ds.send(dp1);  // Send the response to the client
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new RPCServer1();
    }
}
