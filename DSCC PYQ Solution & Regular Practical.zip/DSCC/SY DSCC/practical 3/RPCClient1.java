import java.io.*;
import java.net.*;

class RPCClient1 {
    DatagramSocket ds = null;
    DatagramSocket ds1 = null;
    
    RPCClient1() {
        try {
            InetAddress ia = InetAddress.getLocalHost();
            ds = new DatagramSocket();
            ds1 = new DatagramSocket(1300);
            byte[] b1 = new byte[50];
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

            System.out.println("\nRPC Client\n");

            while (true) {
                System.out.print("Enter message: ");
                String str = br.readLine();
                if (str.equalsIgnoreCase("exit")) {
                    System.out.println("Exiting...");
                    break;
                }

                byte[] b = str.getBytes();
                DatagramPacket dp = new DatagramPacket(b, b.length, ia, 1200);
                ds.send(dp);

                dp = new DatagramPacket(b1, b1.length);
                ds1.receive(dp);
                String s = new String(dp.getData(), 0, dp.getLength());
                System.out.println("\nResult = " + s);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (ds != null && !ds.isClosed()) {
                ds.close();
            }
            if (ds1 != null && !ds1.isClosed()) {
                ds1.close();
            }
            System.out.println("Sockets closed.");
        }
    }

    public static void main(String[] args) {
        new RPCClient1();
    }
}
