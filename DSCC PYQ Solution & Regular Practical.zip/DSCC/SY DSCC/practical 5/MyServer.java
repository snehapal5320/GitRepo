import java.rmi.*;
import java.rmi.registry.*;
public class MyServer{
public static void main(String args[]){
try{
System.out.print("Server started, waiting for client to enter equation");
EquationSolverInterface stub=new EquationSolverClass();
Naming.rebind("EquationSolver",stub);
}catch(Exception e){
System.out.print("exception on server");
System.out.println(e);}
}
}