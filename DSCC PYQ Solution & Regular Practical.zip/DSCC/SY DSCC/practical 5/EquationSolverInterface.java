import java.rmi.*;
import java.util.ArrayList;
public interface EquationSolverInterface extends Remote{
public int EvaluateEquation(String equation,ArrayList<Integer> 
params)throws RemoteException;
}
