import java.rmi.*;
import java.util.List;

public class LibraryClient {
    public static void main(String[] args) {
        try {
            // Look up the remote object
            LibraryRemote library = (LibraryRemote) Naming.lookup("rmi://localhost/LibraryService");

            // Call the remote method to retrieve the list of books
            List<String> books = library.getBookList();

            // Display the list of books
            System.out.println("Books available in the library:");
            for (String book : books) {
                System.out.println(book);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
