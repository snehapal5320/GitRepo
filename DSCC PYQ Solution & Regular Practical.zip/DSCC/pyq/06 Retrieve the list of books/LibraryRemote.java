import java.rmi.*;
import java.util.List;

public interface LibraryRemote extends Remote {
    List<String> getBookList() throws RemoteException;
}
