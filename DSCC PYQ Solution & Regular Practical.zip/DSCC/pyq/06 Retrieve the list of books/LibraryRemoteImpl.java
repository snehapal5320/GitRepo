import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import java.sql.*;

public class LibraryRemoteImpl extends UnicastRemoteObject implements LibraryRemote {

    // Constructor to throw RemoteException
    public LibraryRemoteImpl() throws RemoteException {
        super();
    }

    // Method to fetch books from the database
    public List<String> getBookList() throws RemoteException {
        List<String> books = new ArrayList<>();

        try {
            // Setup database connection (replace with your actual DB URL, user, and password)
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarydb", "root", "root");
            
            // Create a statement to execute the query
            Statement stmt = conn.createStatement();
            
            // Query to fetch all book titles
            String query = "SELECT book_title FROM books";
            ResultSet rs = stmt.executeQuery(query);
            
            // Add each book to the list
            while (rs.next()) {
                books.add(rs.getString("book_title"));
            }

            // Close the resources
            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return books;
    }
}
