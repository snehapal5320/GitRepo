-- Create a database
CREATE DATABASE librarydb;

-- Use the created database
USE librarydb;

-- Create a table to store books
CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_title VARCHAR(255) NOT NULL
);

-- Insert some sample data
INSERT INTO books (book_title) VALUES ('The Great Gatsby');
INSERT INTO books (book_title) VALUES ('1984 by George Orwell');
INSERT INTO books (book_title) VALUES ('To Kill a Mockingbird');
INSERT INTO books (book_title) VALUES ('Pride and Prejudice');
INSERT INTO books (book_title) VALUES ('Moby-Dick');
