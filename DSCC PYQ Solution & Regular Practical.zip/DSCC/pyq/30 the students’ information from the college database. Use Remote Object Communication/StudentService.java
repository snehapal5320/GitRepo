import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface StudentService extends Remote {
    // Method to retrieve student information by student ID
    Student getStudentDetails(int studentId) throws RemoteException;

    // Method to retrieve all students information
    List<Student> getAllStudents() throws RemoteException;
}
