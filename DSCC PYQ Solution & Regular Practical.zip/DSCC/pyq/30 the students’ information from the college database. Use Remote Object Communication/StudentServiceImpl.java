import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentServiceImpl extends UnicastRemoteObject implements StudentService {

    // Constructor
    public StudentServiceImpl() throws RemoteException {
        super();
    }

    // Method to fetch student details by student ID
    @Override
    public Student getStudentDetails(int studentId) throws RemoteException {
        Student student = null;
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/college", "root", "password");
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM students WHERE id = ?")) {
            
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                student = new Student(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("department"),
                    rs.getString("email")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return student;
    }

    // Method to fetch all students' details
    @Override
    public List<Student> getAllStudents() throws RemoteException {
        List<Student> students = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/college", "root", "password");
             Statement stmt = conn.createStatement()) {
            
            ResultSet rs = stmt.executeQuery("SELECT * FROM students");
            
            while (rs.next()) {
                Student student = new Student(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("department"),
                    rs.getString("email")
                );
                students.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    // Main method to start the RMI server
    public static void main(String[] args) {
        try {
            // Create and bind the remote object to the RMI registry
            StudentServiceImpl service = new StudentServiceImpl();
            java.rmi.registry.LocateRegistry.createRegistry(1099);
            java.rmi.Naming.rebind("StudentService", service);
            System.out.println("Student Service is running...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
