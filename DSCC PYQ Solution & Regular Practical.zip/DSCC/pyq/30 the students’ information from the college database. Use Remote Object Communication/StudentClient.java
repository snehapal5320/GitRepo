import java.rmi.Naming;
import java.util.List;
import javax.swing.*;
import java.awt.event.*;

public class StudentClient extends JFrame {

    private JTextField studentIdField;
    private JTextArea resultArea;
    private JButton getDetailsButton, getAllStudentsButton;
    private StudentService studentService;

    public StudentClient() {
        try {
            // Lookup the remote object in the RMI registry
            studentService = (StudentService) Naming.lookup("rmi://localhost/StudentService");

            // Create the GUI components
            studentIdField = new JTextField(10);
            resultArea = new JTextArea(10, 30);
            resultArea.setEditable(false);
            getDetailsButton = new JButton("Get Student Details");
            getAllStudentsButton = new JButton("Get All Students");

            // Button actions
            getDetailsButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    getStudentDetails();
                }
            });

            getAllStudentsButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    getAllStudents();
                }
            });

            // Layout the components
            setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
            add(new JLabel("Enter Student ID:"));
            add(studentIdField);
            add(getDetailsButton);
            add(getAllStudentsButton);
            add(new JScrollPane(resultArea));

            // Window settings
            setTitle("Student Info Retriever");
            setSize(400, 300);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setVisible(true);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getStudentDetails() {
        try {
            int studentId = Integer.parseInt(studentIdField.getText());
            Student student = studentService.getStudentDetails(studentId);
            if (student != null) {
                resultArea.setText(student.toString());
            } else {
                resultArea.setText("Student not found!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getAllStudents() {
        try {
            List<Student> students = studentService.getAllStudents();
            StringBuilder result = new StringBuilder();
            for (Student student : students) {
                result.append(student.toString()).append("\n");
            }
            resultArea.setText(result.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new StudentClient();
    }
}
