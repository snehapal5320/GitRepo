import java.rmi.Naming;
import java.util.Scanner;

public class EquationSolverClient {
    public static void main(String[] args) {
        try {
            EquationSolver solver = (EquationSolver) Naming.lookup("rmi://localhost/EquationSolverService");

            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter an equation (e.g., 5+3*2): ");
            String equation = scanner.nextLine();

            double result = solver.solveEquation(equation);

            System.out.println("The result of the equation is: " + result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
