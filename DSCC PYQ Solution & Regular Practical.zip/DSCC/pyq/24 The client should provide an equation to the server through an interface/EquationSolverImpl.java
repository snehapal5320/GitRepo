import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class EquationSolverImpl extends UnicastRemoteObject implements EquationSolver {

    public EquationSolverImpl() throws RemoteException {
        super();
    }

    @Override
    public double solveEquation(String equation) throws RemoteException {
        double result = 0;
        try {
            // Using Java's ScriptEngine to evaluate the equation
            ScriptEngineManager manager = new ScriptEngineManager();
            ScriptEngine engine = manager.getEngineByName("JavaScript");
            result = (double) engine.eval(equation);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RemoteException("Error solving equation: " + e.getMessage());
        }
        return result;
    }

    public static void main(String[] args) {
        try {
            java.rmi.registry.LocateRegistry.createRegistry(1099);
            EquationSolverImpl server = new EquationSolverImpl();
            Naming.rebind("EquationSolverService", server);
            System.out.println("Equation Solver Server is running...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
