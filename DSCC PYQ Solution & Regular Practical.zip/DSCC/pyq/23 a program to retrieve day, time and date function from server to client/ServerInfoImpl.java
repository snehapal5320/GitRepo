import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ServerInfoImpl extends UnicastRemoteObject implements ServerInfo {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/server_info";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "your_password";

    public ServerInfoImpl() throws RemoteException {
        super();
    }

    @Override
    public String getDay() throws RemoteException {
        return fetchData("day_of_week");
    }

    @Override
    public String getTime() throws RemoteException {
        return fetchData("time_of_day");
    }

    @Override
    public String getDate() throws RemoteException {
        return fetchData("date_today");
    }

    private String fetchData(String columnName) {
        String result = "";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT " + columnName + " FROM datetime_info LIMIT 1");

            if (rs.next()) {
                result = rs.getString(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public static void main(String[] args) {
        try {
            java.rmi.registry.LocateRegistry.createRegistry(1099);
            ServerInfoImpl server = new ServerInfoImpl();
            Naming.rebind("ServerInfoService", server);
            System.out.println("Server is running...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
