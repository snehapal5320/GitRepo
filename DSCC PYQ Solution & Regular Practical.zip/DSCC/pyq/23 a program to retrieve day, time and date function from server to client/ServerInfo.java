import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ServerInfo extends Remote {
    String getDay() throws RemoteException;
    String getTime() throws RemoteException;
    String getDate() throws RemoteException;
}
