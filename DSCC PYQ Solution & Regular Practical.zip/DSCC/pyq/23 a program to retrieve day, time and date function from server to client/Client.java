import java.rmi.Naming;

public class Client {
    public static void main(String[] args) {
        try {
            ServerInfo server = (ServerInfo) Naming.lookup("rmi://localhost/ServerInfoService");

            String day = server.getDay();
            String time = server.getTime();
            String date = server.getDate();

            System.out.println("Server Day: " + day);
            System.out.println("Server Time: " + time);
            System.out.println("Server Date: " + date);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
