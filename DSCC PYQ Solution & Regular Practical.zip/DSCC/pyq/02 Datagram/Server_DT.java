import java.net.*;
import java.io.*;
import java.util.Date;

public class Server_DT {

    public static void main(String[] args) throws IOException {
        // Step 1. Reserve a port number on the Server to offer this service
        ServerSocket ss = new ServerSocket(5000);
        
        // (Optional) To confirm Server Reserved specified port or not
        System.out.println("The Server has reserved port No.: " + ss.getLocalPort() + " for this Service");
        
        // Step 2. Wait for a client to connect
        Socket cs = ss.accept();  // Socket is created when client communicates with the server
        
        // To confirm Server communicated through the socket or not
        System.out.println("Client with IP Address " + cs.getInetAddress() + " has communicated via port No.: " + cs.getPort());
        
        // Get the current date and time
        Date d = new Date();
        String s = "Current Date & Time on Server is: " + d;
        
        // Send String s to client via the client socket
        PrintWriter toClient = new PrintWriter(cs.getOutputStream(), true);
        toClient.println(s);  // Use println to send the string with a newline
        
        // Close the output stream, client socket, and server socket
        toClient.close();
        cs.close();
        ss.close();
    }
}
