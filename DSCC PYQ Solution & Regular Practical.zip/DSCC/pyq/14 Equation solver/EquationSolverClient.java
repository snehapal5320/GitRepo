import java.rmi.Naming;
import java.util.Scanner;

public class EquationSolverClient {
    public static void main(String[] args) {
        try {
            // Connect to the remote service
            EquationSolver solver = (EquationSolver) Naming.lookup("rmi://localhost/EquationSolver");

            // Get input values for a and b
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter value for a: ");
            int a = scanner.nextInt();
            System.out.print("Enter value for b: ");
            int b = scanner.nextInt();

            // Call the remote method
            int result = solver.solveEquation(a, b);

            // Display the result
            System.out.println("Result of (a + b)^2 = " + result);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
