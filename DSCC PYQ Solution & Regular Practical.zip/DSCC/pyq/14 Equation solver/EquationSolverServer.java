import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class EquationSolverServer {
    public static void main(String[] args) {
        try {
            // Start the RMI registry
            LocateRegistry.createRegistry(1099);
            System.out.println("RMI Registry started.");

            // Create and bind the remote object
            EquationSolverImpl solver = new EquationSolverImpl();
            Naming.rebind("rmi://localhost/EquationSolver", solver);

            System.out.println("EquationSolver is ready.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
