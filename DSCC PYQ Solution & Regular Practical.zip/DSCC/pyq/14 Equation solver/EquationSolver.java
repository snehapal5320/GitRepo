import java.rmi.Remote;
import java.rmi.RemoteException;

public interface EquationSolver extends Remote {
    // Method to solve the equation (a + b)^2
    int solveEquation(int a, int b) throws RemoteException;
}
