import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface FlightService extends Remote {
    // Method to retrieve traveler details
    List<String> getTravelerDetails(String flightNumber) throws RemoteException;
}
