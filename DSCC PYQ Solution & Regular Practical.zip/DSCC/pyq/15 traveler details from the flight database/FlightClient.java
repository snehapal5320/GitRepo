import java.rmi.Naming;
import java.util.List;
import java.util.Scanner;

public class FlightClient {
    public static void main(String[] args) {
        try {
            // Connect to the remote service
            FlightService flightService = (FlightService) Naming.lookup("rmi://localhost/FlightService");

            // Get input from the user
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter flight number: ");
            String flightNumber = scanner.nextLine();

            // Retrieve traveler details
            List<String> travelerDetails = flightService.getTravelerDetails(flightNumber);

            // Display traveler details
            if (travelerDetails.isEmpty()) {
                System.out.println("No travelers found for flight number: " + flightNumber);
            } else {
                System.out.println("Travelers for flight number " + flightNumber + ":");
                for (String details : travelerDetails) {
                    System.out.println(details);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
