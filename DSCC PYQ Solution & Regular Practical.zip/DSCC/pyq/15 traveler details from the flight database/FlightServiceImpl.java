import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FlightServiceImpl extends UnicastRemoteObject implements FlightService {

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/flight_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "password";

    // Constructor
    public FlightServiceImpl() throws RemoteException {
        super();
    }

    // Fetch traveler details for a given flight number
    @Override
    public List<String> getTravelerDetails(String flightNumber) throws RemoteException {
        List<String> travelerDetails = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM travelers WHERE flight_number = ?")) {

            stmt.setString(1, flightNumber);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String details = "ID: " + rs.getInt("traveler_id") +
                                 ", Name: " + rs.getString("name") +
                                 ", Age: " + rs.getInt("age") +
                                 ", Destination: " + rs.getString("destination");
                travelerDetails.add(details);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RemoteException("Database error: " + e.getMessage());
        }

        return travelerDetails;
    }
}
