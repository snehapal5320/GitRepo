import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class FlightServer {
    public static void main(String[] args) {
        try {
            // Start RMI registry
            LocateRegistry.createRegistry(1099);
            System.out.println("RMI Registry started.");

            // Create and bind the remote object
            FlightServiceImpl flightService = new FlightServiceImpl();
            Naming.rebind("rmi://localhost/FlightService", flightService);

            System.out.println("FlightService is ready.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
