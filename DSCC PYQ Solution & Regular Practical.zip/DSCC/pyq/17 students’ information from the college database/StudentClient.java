import java.rmi.Naming;
import java.util.List;

public class StudentClient {
    public static void main(String[] args) {
        try {
            // Connect to the remote service
            StudentService studentService = (StudentService) Naming.lookup("rmi://localhost/StudentService");

            // Retrieve student details
            List<String> students = studentService.getStudents();

            // Display student details
            if (students.isEmpty()) {
                System.out.println("No student records found.");
            } else {
                System.out.println("Student Information:");
                for (String student : students) {
                    System.out.println(student);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
