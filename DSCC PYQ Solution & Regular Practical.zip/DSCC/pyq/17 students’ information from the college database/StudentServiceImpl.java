import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentServiceImpl extends UnicastRemoteObject implements StudentService {

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/college_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "password";

    // Constructor
    public StudentServiceImpl() throws RemoteException {
        super();
    }

    // Fetch students' information from the database
    @Override
    public List<String> getStudents() throws RemoteException {
        List<String> studentDetails = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM students")) {

            while (rs.next()) {
                String details = "ID: " + rs.getInt("student_id") +
                                 ", Name: " + rs.getString("name") +
                                 ", Course: " + rs.getString("course") +
                                 ", Year: " + rs.getInt("year") +
                                 ", Marks: " + rs.getFloat("marks");
                studentDetails.add(details);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RemoteException("Database error: " + e.getMessage());
        }

        return studentDetails;
    }
}
