import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class StudentServer {
    public static void main(String[] args) {
        try {
            // Start RMI registry
            LocateRegistry.createRegistry(1099);
            System.out.println("RMI Registry started.");

            // Create and bind the remote object
            StudentServiceImpl studentService = new StudentServiceImpl();
            Naming.rebind("rmi://localhost/StudentService", studentService);

            System.out.println("StudentService is ready.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
