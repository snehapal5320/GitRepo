import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface StudentService extends Remote {
    // Method to retrieve students' information
    List<String> getStudents() throws RemoteException;
}
