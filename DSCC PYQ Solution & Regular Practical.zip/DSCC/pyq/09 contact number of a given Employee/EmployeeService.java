import java.rmi.Remote;
import java.rmi.RemoteException;

public interface EmployeeService extends Remote {
    String getEmployeeContactNumber(int employeeId) throws RemoteException;
}
