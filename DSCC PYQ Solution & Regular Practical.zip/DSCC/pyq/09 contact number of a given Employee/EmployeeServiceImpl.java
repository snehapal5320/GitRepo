import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Map;

public class EmployeeServiceImpl extends UnicastRemoteObject implements EmployeeService {

    private Map<Integer, String> employeeDatabase;

    // Constructor to initialize some sample data (simulating a database)
    public EmployeeServiceImpl() throws RemoteException {
        super();
        employeeDatabase = new HashMap<>();
        // Sample data: employeeId -> contactNumber
        employeeDatabase.put(101, "555-1234");
        employeeDatabase.put(102, "555-5678");
        employeeDatabase.put(103, "555-8765");
        employeeDatabase.put(104, "555-4321");
    }

    // Method to retrieve the employee contact number
    @Override
    public String getEmployeeContactNumber(int employeeId) throws RemoteException {
        // Simulate retrieving data from a database
        if (employeeDatabase.containsKey(employeeId)) {
            return employeeDatabase.get(employeeId);
        } else {
            return "Employee not found!";
        }
    }
}
