import java.rmi.Naming;
import java.util.Scanner;

public class EmployeeClient {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Look up the remote object in the RMI registry
            EmployeeService employeeService = (EmployeeService) Naming.lookup("rmi://localhost/EmployeeService");

            // Prompt the user to enter an employee ID
            System.out.println("Enter Employee ID:");
            int employeeId = scanner.nextInt();

            // Call the remote method to retrieve the employee's contact number
            String contactNumber = employeeService.getEmployeeContactNumber(employeeId);

            // Output the result
            System.out.println("Employee Contact Number: " + contactNumber);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
}
