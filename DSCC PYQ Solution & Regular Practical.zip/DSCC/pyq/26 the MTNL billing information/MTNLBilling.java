import java.rmi.Remote;
import java.rmi.RemoteException;

public interface MTNLBilling extends Remote {
    String getBillingInfo(String accountNumber) throws RemoteException;
}
