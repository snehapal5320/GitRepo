import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MTNLBillingImpl extends UnicastRemoteObject implements MTNLBilling {

    public MTNLBillingImpl() throws RemoteException {
        super();
    }

    @Override
    public String getBillingInfo(String accountNumber) throws RemoteException {
        String url = "jdbc:mysql://localhost:3306/mtnl";
        String user = "root";
        String password = "password";
        String billingInfo = "No billing information found.";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            String query = "SELECT * FROM bills WHERE account_number = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, accountNumber);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                billingInfo = "Account Number: " + rs.getString("account_number") +
                              ", Name: " + rs.getString("name") +
                              ", Amount Due: " + rs.getDouble("amount_due") +
                              ", Due Date: " + rs.getString("due_date");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return billingInfo;
    }

    public static void main(String[] args) {
        try {
            java.rmi.registry.LocateRegistry.createRegistry(1099);
            MTNLBillingImpl server = new MTNLBillingImpl();
            Naming.rebind("MTNLBillingService", server);
            System.out.println("MTNL Billing Server is running...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
