import java.rmi.Naming;
import java.util.Scanner;

public class MTNLBillingClient {
    public static void main(String[] args) {
        try {
            MTNLBilling billingService = (MTNLBilling) Naming.lookup("rmi://localhost/MTNLBillingService");

            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter Account Number: ");
            String accountNumber = scanner.nextLine();

            String billingInfo = billingService.getBillingInfo(accountNumber);
            System.out.println("Billing Information: " + billingInfo);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
