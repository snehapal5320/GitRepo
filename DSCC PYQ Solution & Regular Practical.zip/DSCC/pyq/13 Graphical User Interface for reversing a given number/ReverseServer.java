import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class ReverseServer {
    public static void main(String[] args) {
        try {
            // Start RMI registry
            LocateRegistry.createRegistry(1099);
            System.out.println("RMI Registry started.");

            // Create and bind the remote object
            ReverseServiceImpl reverseService = new ReverseServiceImpl();
            Naming.rebind("rmi://localhost/ReverseService", reverseService);

            System.out.println("ReverseService is ready.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
