import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.Naming;

public class ReverseClientGUI extends JFrame {

    private JTextField inputField;
    private JTextField resultField;
    private JButton reverseButton;

    public ReverseClientGUI() {
        // Set up the GUI
        setTitle("Number Reverser");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 2));

        // Create components
        JLabel inputLabel = new JLabel("Enter a number:");
        inputField = new JTextField();

        JLabel resultLabel = new JLabel("Reversed number:");
        resultField = new JTextField();
        resultField.setEditable(false);

        reverseButton = new JButton("Reverse");

        // Add components to the frame
        add(inputLabel);
        add(inputField);
        add(resultLabel);
        add(resultField);
        add(reverseButton);

        // Add event listener for the reverse button
        reverseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Connect to the remote service
                    ReverseService reverseService = (ReverseService) Naming.lookup("rmi://localhost/ReverseService");

                    // Get the input number
                    int number = Integer.parseInt(inputField.getText());

                    // Call the remote method and display the result
                    int reversedNumber = reverseService.reverseNumber(number);
                    resultField.setText(String.valueOf(reversedNumber));

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(ReverseClientGUI.this,
                            "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    public static void main(String[] args) {
        // Show the GUI
        SwingUtilities.invokeLater(() -> {
            ReverseClientGUI gui = new ReverseClientGUI();
            gui.setVisible(true);
        });
    }
}

