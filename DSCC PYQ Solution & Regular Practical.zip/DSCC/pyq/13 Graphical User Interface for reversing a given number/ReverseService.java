import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ReverseService extends Remote {
    // Method to reverse a given number
    int reverseNumber(int number) throws RemoteException;
}
