import java.rmi.Naming;
import java.util.Scanner;

public class OddEvenClient {
    public static void main(String[] args) {
        try {
            OddEvenChecker checker = (OddEvenChecker) Naming.lookup("rmi://localhost/OddEvenService");

            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter a number: ");
            int number = scanner.nextInt();

            String result = checker.checkOddEven(number);
            System.out.println("The number " + number + " is " + result);

            // If the number is even, calculate and display its table
            if (result.equals("Even")) {
                System.out.println("The table of " + number + " is:");
                for (int i = 1; i <= 10; i++) {
                    System.out.println(number + " x " + i + " = " + (number * i));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
