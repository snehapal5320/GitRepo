import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class OddEvenCheckerImpl extends UnicastRemoteObject implements OddEvenChecker {

    public OddEvenCheckerImpl() throws RemoteException {
        super();
    }

    @Override
    public String checkOddEven(int number) throws RemoteException {
        return (number % 2 == 0) ? "Even" : "Odd";
    }

    public static void main(String[] args) {
        try {
            java.rmi.registry.LocateRegistry.createRegistry(1099);
            OddEvenCheckerImpl server = new OddEvenCheckerImpl();
            Naming.rebind("OddEvenService", server);
            System.out.println("Odd-Even Checker Server is running...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
