import java.rmi.Remote;
import java.rmi.RemoteException;

public interface OddEvenChecker extends Remote {
    String checkOddEven(int number) throws RemoteException;
}
