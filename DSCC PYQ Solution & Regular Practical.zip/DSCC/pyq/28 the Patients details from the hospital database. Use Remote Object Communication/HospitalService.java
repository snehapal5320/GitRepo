import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface HospitalService extends Remote {
    // Method to retrieve patient details by ID
    Patient getPatientDetails(int patientId) throws RemoteException;
    
    // Method to retrieve all patients
    List<Patient> getAllPatients() throws RemoteException;
}
