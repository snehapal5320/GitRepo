import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.rmi.Naming;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HospitalServiceImpl extends UnicastRemoteObject implements HospitalService {

    // Constructor to export the object
    public HospitalServiceImpl() throws RemoteException {
        super();
    }

    // Method to get patient details by ID
    @Override
    public Patient getPatientDetails(int patientId) throws RemoteException {
        Patient patient = null;
        try {
            // Establishing a connection to the database
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db", "root", "password");
            
            // Query to retrieve the patient details
            String query = "SELECT * FROM patients WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, patientId);
            ResultSet rs = stmt.executeQuery();

            // If patient found, create a Patient object
            if (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int age = rs.getInt("age");
                String disease = rs.getString("disease");
                patient = new Patient(id, name, age, disease);
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return patient;
    }

    // Method to get all patients
    @Override
    public List<Patient> getAllPatients() throws RemoteException {
        List<Patient> patients = new ArrayList<>();
        try {
            // Establishing a connection to the database
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db", "root", "password");
            
            // Query to retrieve all patients
            String query = "SELECT * FROM patients";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            // Retrieve all patients and add them to the list
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int age = rs.getInt("age");
                String disease = rs.getString("disease");
                Patient patient = new Patient(id, name, age, disease);
                patients.add(patient);
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return patients;
    }

    public static void main(String[] args) {
        try {
            // Register the HospitalServiceImpl with RMI registry
            java.rmi.registry.LocateRegistry.createRegistry(1099);
            HospitalServiceImpl hospitalService = new HospitalServiceImpl();
            Naming.rebind("HospitalService", hospitalService);
            System.out.println("Hospital Service is running...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
