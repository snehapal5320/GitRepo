import java.rmi.Naming;
import java.util.List;
import java.util.Scanner;

public class HospitalClient {

    public static void main(String[] args) {
        try {
            // Look up the remote object
            HospitalService hospitalService = (HospitalService) Naming.lookup("rmi://localhost/HospitalService");

            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter 1 to get all patients, or 2 to get a patient by ID:");
            int choice = scanner.nextInt();

            if (choice == 1) {
                // Retrieve all patients
                List<Patient> patients = hospitalService.getAllPatients();
                System.out.println("List of Patients:");
                for (Patient patient : patients) {
                    System.out.println(patient);
                }
            } else if (choice == 2) {
                // Retrieve a patient by ID
                System.out.print("Enter patient ID: ");
                int patientId = scanner.nextInt();
                Patient patient = hospitalService.getPatientDetails(patientId);
                if (patient != null) {
                    System.out.println("Patient Details: " + patient);
                } else {
                    System.out.println("Patient not found!");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
