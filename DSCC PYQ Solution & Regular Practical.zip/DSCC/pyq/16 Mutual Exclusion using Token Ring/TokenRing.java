import java.util.Scanner;

public class TokenRing {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of nodes in the ring: ");
        int numNodes = scanner.nextInt();

        // Logical ring of nodes
        int token = 0; // Initially, the token is with node 0
        boolean[] requestingCriticalSection = new boolean[numNodes];

        while (true) {
            System.out.println("\nCurrent token holder: Node " + token);
            System.out.println("Do you want Node " + token + " to enter the critical section? (yes/no): ");
            String response = scanner.next();

            if (response.equalsIgnoreCase("yes")) {
                requestingCriticalSection[token] = true;

                // Node enters the critical section
                System.out.println("Node " + token + " has entered the critical section.");
                System.out.println("Node " + token + " is performing its task...");

                // Simulate some work
                try {
                    Thread.sleep(2000); // Task takes 2 seconds
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                System.out.println("Node " + token + " has exited the critical section.");
                requestingCriticalSection[token] = false;
            }

            // Pass the token to the next node in the ring
            token = (token + 1) % numNodes;
        }
    }
}
