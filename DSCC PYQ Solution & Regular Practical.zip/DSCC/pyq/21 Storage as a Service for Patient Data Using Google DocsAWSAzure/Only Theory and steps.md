### Implementing "Storage as a Service" for Patient Data Using Google Docs/AWS/Azure

In this task, you'll set up a **Storage as a Service (StaaS)** application where patient data is stored securely in the cloud using a storage platform (Google Cloud, AWS, or Azure). Below are the steps and code implementation.

---

### Steps to Implement

1. **Choose Your Cloud Provider**:
   - **Google Cloud Storage**: Use Google Cloud SDK.
   - **AWS S3**: Use AWS SDK for Java.
   - **Azure Blob Storage**: Use Azure SDK for Java.

2. **Setup Environment**:
   - Create an account on your chosen cloud provider.
   - Set up a storage service (Google Cloud Bucket, AWS S3 Bucket, or Azure Blob Container).
   - Configure authentication credentials for your application.

3. **Create Patient Data Storage**:
   - Create a Java application to upload, retrieve, and manage patient data.
   - Use the respective cloud SDKs to interact with the storage service.

---

### Example: Using AWS S3

#### **Step 1: Prerequisites**
- Install the **AWS SDK for Java**.
- Configure AWS credentials in the `~/.aws/credentials` file:
  ```
  [default]
  aws_access_key_id = YOUR_ACCESS_KEY
  aws_secret_access_key = YOUR_SECRET_KEY
  ```

---

#### **Step 2: Create an S3 Bucket**
- Go to the AWS Management Console.
- Create a bucket named `patient-data`.

---

#### **Step 3: Java Code Implementation**

**Dependencies (Maven `pom.xml`)**:
```xml
<dependency>
    <groupId>software.amazon.awssdk</groupId>
    <artifactId>s3</artifactId>
    <version>2.20.5</version>
</dependency>
<dependency>
    <groupId>software.amazon.awssdk</groupId>
    <artifactId>sdk-core</artifactId>
    <version>2.20.5</version>
</dependency>
```

**Java Code**:
```java
import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;
import java.io.File;
import java.util.List;

public class PatientDataStorage {

    private static final String BUCKET_NAME = "patient-data";

    public static void main(String[] args) {
        Region region = Region.US_EAST_1;
        S3Client s3 = S3Client.builder()
                .region(region)
                .credentialsProvider(ProfileCredentialsProvider.create())
                .build();

        // Upload patient data
        uploadFile(s3, "patient1.json", "C:\\data\\patient1.json");

        // List files in the bucket
        listFiles(s3);

        // Download patient data
        downloadFile(s3, "patient1.json", "C:\\downloads\\patient1.json");

        // Delete a file
        deleteFile(s3, "patient1.json");

        s3.close();
    }

    private static void uploadFile(S3Client s3, String key, String filePath) {
        PutObjectRequest request = PutObjectRequest.builder()
                .bucket(BUCKET_NAME)
                .key(key)
                .build();

        s3.putObject(request, new File(filePath).toPath());
        System.out.println("File uploaded: " + key);
    }

    private static void listFiles(S3Client s3) {
        ListObjectsV2Request request = ListObjectsV2Request.builder()
                .bucket(BUCKET_NAME)
                .build();

        ListObjectsV2Response response = s3.listObjectsV2(request);
        List<S3Object> objects = response.contents();

        System.out.println("Files in the bucket:");
        for (S3Object object : objects) {
            System.out.println("- " + object.key());
        }
    }

    private static void downloadFile(S3Client s3, String key, String downloadPath) {
        GetObjectRequest request = GetObjectRequest.builder()
                .bucket(BUCKET_NAME)
                .key(key)
                .build();

        s3.getObject(request, new File(downloadPath).toPath());
        System.out.println("File downloaded: " + key);
    }

    private static void deleteFile(S3Client s3, String key) {
        DeleteObjectRequest request = DeleteObjectRequest.builder()
                .bucket(BUCKET_NAME)
                .key(key)
                .build();

        s3.deleteObject(request);
        System.out.println("File deleted: " + key);
    }
}
```

---

### Example: Using Azure Blob Storage

#### Prerequisites:
- Install Azure SDK for Java.
- Set up Azure Blob Storage and get connection strings from the Azure portal.

**Dependencies**:
```xml
<dependency>
    <groupId>com.azure</groupId>
    <artifactId>azure-storage-blob</artifactId>
    <version>12.23.0</version>
</dependency>
```

**Java Code**:
```java
import com.azure.storage.blob.*;
import com.azure.storage.blob.models.*;

import java.io.*;

public class PatientDataStorageAzure {

    private static final String CONNECTION_STRING = "YOUR_AZURE_CONNECTION_STRING";
    private static final String CONTAINER_NAME = "patient-data";

    public static void main(String[] args) {
        BlobServiceClient blobServiceClient = new BlobServiceClientBuilder()
                .connectionString(CONNECTION_STRING)
                .buildClient();

        BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient(CONTAINER_NAME);

        // Upload a file
        uploadFile(containerClient, "patient1.json", "C:\\data\\patient1.json");

        // List blobs
        listBlobs(containerClient);

        // Download a file
        downloadFile(containerClient, "patient1.json", "C:\\downloads\\patient1.json");
    }

    private static void uploadFile(BlobContainerClient containerClient, String blobName, String filePath) {
        BlobClient blobClient = containerClient.getBlobClient(blobName);
        blobClient.uploadFromFile(filePath, true);
        System.out.println("File uploaded: " + blobName);
    }

    private static void listBlobs(BlobContainerClient containerClient) {
        System.out.println("Blobs in the container:");
        for (BlobItem blobItem : containerClient.listBlobs()) {
            System.out.println("- " + blobItem.getName());
        }
    }

    private static void downloadFile(BlobContainerClient containerClient, String blobName, String downloadPath) {
        BlobClient blobClient = containerClient.getBlobClient(blobName);
        blobClient.downloadToFile(downloadPath, true);
        System.out.println("File downloaded: " + blobName);
    }
}
```

---

### Testing

1. **Upload Files**: Save patient data (e.g., `patient1.json`) locally, then upload it to the cloud storage using the application.
2. **List Files**: Verify the files are stored in the cloud by listing all objects in the storage bucket/container.
3. **Download Files**: Retrieve specific patient files from the cloud storage.
4. **Delete Files**: Remove specific files from the storage.

---

### Security Considerations
- **Authentication**: Use IAM roles (AWS) or Managed Identity (Azure) for secure access.
- **Encryption**: Enable server-side encryption for data in storage.
- **Access Policies**: Use fine-grained access policies to restrict access to the storage.

This implementation allows a seamless storage and retrieval of patient data using cloud storage services, demonstrating Storage as a Service.