import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class LibraryServer extends UnicastRemoteObject implements Library {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/library_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "your_password";

    public LibraryServer() throws RemoteException {
        super();
    }

    @Override
    public List<String> getBooks() throws RemoteException {
        List<String> books = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT title, author, year FROM books");

            while (rs.next()) {
                String book = rs.getString("title") + " by " + rs.getString("author") + " (" + rs.getInt("year") + ")";
                books.add(book);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return books;
    }

    public static void main(String[] args) {
        try {
            java.rmi.registry.LocateRegistry.createRegistry(1099);
            LibraryServer server = new LibraryServer();
            java.rmi.Naming.rebind("LibraryService", server);
            System.out.println("Library Server is running...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
