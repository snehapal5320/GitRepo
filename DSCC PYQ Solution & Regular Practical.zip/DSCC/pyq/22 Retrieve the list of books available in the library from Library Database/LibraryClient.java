import java.rmi.Naming;
import java.util.List;

public class LibraryClient {
    public static void main(String[] args) {
        try {
            Library library = (Library) Naming.lookup("rmi://localhost/LibraryService");
            List<String> books = library.getBooks();

            System.out.println("Books available in the library:");
            for (String book : books) {
                System.out.println("- " + book);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
