import java.rmi.Naming;
import java.util.Scanner;

public class PowerClient {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Look up the remote object in the RMI registry
            PowerService powerService = (PowerService) Naming.lookup("rmi://localhost/PowerService");

            // Get inputs from the user
            System.out.print("Enter the value of Y: ");
            double Y = scanner.nextDouble();

            System.out.print("Enter the value of n: ");
            int n = scanner.nextInt();

            // Call the remote method to calculate Y^n
            double result = powerService.calculatePower(Y, n);

            // Output the result
            System.out.println("Result: " + Y + " raised to the power of " + n + " is: " + result);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
}
