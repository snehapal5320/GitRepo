import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class PowerServiceImpl extends UnicastRemoteObject implements PowerService {

    // Constructor
    public PowerServiceImpl() throws RemoteException {
        super();
    }

    // Method to calculate Y^n
    @Override
    public double calculatePower(double Y, int n) throws RemoteException {
        // Using Math.pow to calculate Y raised to the power n
        return Math.pow(Y, n);
    }
}
