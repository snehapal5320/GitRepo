import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class PowerServer {
    public static void main(String[] args) {
        try {
            // Start the RMI registry on the default port 1099
            LocateRegistry.createRegistry(1099);
            System.out.println("RMI registry started...");

            // Create the remote object (service)
            PowerServiceImpl powerService = new PowerServiceImpl();
            
            // Bind the remote object to the RMI registry
            Naming.rebind("rmi://localhost/PowerService", powerService);
            System.out.println("PowerService object bound in registry");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
