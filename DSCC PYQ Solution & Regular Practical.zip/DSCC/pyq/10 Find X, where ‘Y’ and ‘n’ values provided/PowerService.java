import java.rmi.Remote;
import java.rmi.RemoteException;

public interface PowerService extends Remote {
    // Method to calculate X = Y^n
    double calculatePower(double Y, int n) throws RemoteException;
}
