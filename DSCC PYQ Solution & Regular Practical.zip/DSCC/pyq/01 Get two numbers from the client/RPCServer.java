import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

// Remote Interface
interface SumService extends Remote {
    int addNumbers(int a, int b) throws RemoteException;
}

// Implementation of the Remote Interface
class SumServiceImpl extends UnicastRemoteObject implements SumService {
    protected SumServiceImpl() throws RemoteException {
        super();
    }

    @Override
    public int addNumbers(int a, int b) throws RemoteException {
        return a + b; // Process summation
    }
}

// Server Code
public class RPCServer {
    public static void main(String[] args) {
        try {
            // Create an instance of the service
            SumService service = new SumServiceImpl();
            
            // Bind the service to a name in the registry
            Registry registry = LocateRegistry.createRegistry(5000); // Change port to 5000
            registry.rebind("SumService", service);
            System.out.println("Server is running on port 5000...");
                    } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
