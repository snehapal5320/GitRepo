import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class RPCClient {
    public static void main(String[] args) {
        try {
            // Locate the registry and look up the remote service
            Registry registry = LocateRegistry.getRegistry("localhost", 5000); // Match the server's port
            SumService service = (SumService) registry.lookup("SumService");
                        
            // Get numbers from the user (simulate input)
            int num1 = 10;
            int num2 = 20;
            
            // Call the remote method and get the result
            int result = service.addNumbers(num1, num2);
            
            // Display the result
            System.out.println("The sum of " + num1 + " and " + num2 + " is: " + result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
