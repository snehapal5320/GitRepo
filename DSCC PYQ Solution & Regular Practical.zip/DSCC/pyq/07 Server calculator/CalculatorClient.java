import java.rmi.Naming;

public class CalculatorClient {
    public static void main(String[] args) {
        try {
            // Look up the remote object in the RMI registry
            CalculatorRemote calculator = (CalculatorRemote) Naming.lookup("rmi://localhost/CalculatorRemote");

            // Perform some operations
            double a = 10;
            double b = 5;

            System.out.println("Addition: " + calculator.ADD(a, b));
            System.out.println("Multiplication: " + calculator.MUL(a, b));
            System.out.println("Subtraction: " + calculator.SUB(a, b));
            System.out.println("Division: " + calculator.DIV(a, b));
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
