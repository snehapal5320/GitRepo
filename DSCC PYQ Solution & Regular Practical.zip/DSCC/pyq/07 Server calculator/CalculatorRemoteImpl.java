import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class CalculatorRemoteImpl extends UnicastRemoteObject implements CalculatorRemote {

    public CalculatorRemoteImpl() throws RemoteException {
        super();
    }

    @Override
    public double ADD(double a, double b) throws RemoteException {
        return a + b;
    }

    @Override
    public double MUL(double a, double b) throws RemoteException {
        return a * b;
    }

    @Override
    public double SUB(double a, double b) throws RemoteException {
        return a - b;
    }

    @Override
    public double DIV(double a, double b) throws RemoteException {
        if (b == 0) {
            throw new RemoteException("Division by zero is not allowed");
        }
        return a / b;
    }
}
