import java.rmi.Remote;
import java.rmi.RemoteException;

public interface CalculatorRemote extends Remote {
    double ADD(double a, double b) throws RemoteException;
    double MUL(double a, double b) throws RemoteException;
    double SUB(double a, double b) throws RemoteException;
    double DIV(double a, double b) throws RemoteException;
}
