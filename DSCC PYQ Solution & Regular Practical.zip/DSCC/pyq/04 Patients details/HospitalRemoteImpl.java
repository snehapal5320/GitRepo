import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HospitalRemoteImpl extends UnicastRemoteObject implements HospitalRemote {
    // Constructor
    public HospitalRemoteImpl() throws RemoteException {
        super();
    }

    // Implement the method to get a patient's details by their ID
    public Patient getPatientDetails(int patientId) throws RemoteException {
        Patient patient = null;
        try {
            // Setup database connection
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital", "root", "password");
            String query = "SELECT * FROM patients WHERE patient_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, patientId);
            ResultSet rs = stmt.executeQuery();

            // Check if the patient exists and retrieve details
            if (rs.next()) {
                patient = new Patient(rs.getInt("patient_id"), rs.getString("name"), rs.getString("dob"), rs.getString("address"));
            }

            // Close resources
            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return patient;
    }

    // Implement the method to get all patients
    public List<Patient> getAllPatients() throws RemoteException {
        List<Patient> patients = new ArrayList<>();
        try {
            // Setup database connection
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital", "root", "password");
            String query = "SELECT * FROM patients";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            // Retrieve all patients
            while (rs.next()) {
                patients.add(new Patient(rs.getInt("patient_id"), rs.getString("name"), rs.getString("dob"), rs.getString("address")));
            }

            // Close resources
            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return patients;
    }
}
