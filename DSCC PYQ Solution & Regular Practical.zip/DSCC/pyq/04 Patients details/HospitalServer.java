import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class HospitalServer {
    public static void main(String[] args) {
        try {
            // Create an instance of the remote object
            HospitalRemoteImpl obj = new HospitalRemoteImpl();
            
            // Start RMI registry on port 2000 (change the port)
            LocateRegistry.createRegistry(2000);  // Changed port to 2000
            
            // Bind the remote object to a name in the RMI registry
            Naming.rebind("rmi://localhost:2000/HospitalService", obj);  // Specify the new port here
            
            System.out.println("Hospital RMI Server is ready.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
