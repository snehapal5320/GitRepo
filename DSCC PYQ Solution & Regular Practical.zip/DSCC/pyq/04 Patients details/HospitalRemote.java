import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface HospitalRemote extends Remote {
    // Define the method to retrieve patient details by their ID
    Patient getPatientDetails(int patientId) throws RemoteException;
    List<Patient> getAllPatients() throws RemoteException;
}
