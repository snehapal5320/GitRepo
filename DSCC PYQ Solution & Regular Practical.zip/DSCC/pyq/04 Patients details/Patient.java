public class Patient {
    private int patientId;
    private String name;
    private String dob;
    private String address;

    public Patient(int patientId, String name, String dob, String address) {
        this.patientId = patientId;
        this.name = name;
        this.dob = dob;
        this.address = address;
    }

    // Getters and Setters
    public int getPatientId() {
        return patientId;
    }

    public String getName() {
        return name;
    }

    public String getDob() {
        return dob;
    }

    public String getAddress() {
        return address;
    }
}
