import java.rmi.Naming;

public class HospitalClient {
    public static void main(String[] args) {
        try {
            // Lookup the remote object in the RMI registry
            HospitalRemote obj = (HospitalRemote) Naming.lookup("rmi://localhost/HospitalService");

            // Fetch a specific patient's details
            Patient patient = obj.getPatientDetails(1);  // Example: Patient ID = 1
            if (patient != null) {
                System.out.println("Patient ID: " + patient.getPatientId());
                System.out.println("Name: " + patient.getName());
                System.out.println("DOB: " + patient.getDob());
                System.out.println("Address: " + patient.getAddress());
            } else {
                System.out.println("Patient not found.");
            }

            // Fetch all patients
            System.out.println("\nAll Patients:");
            for (Patient p : obj.getAllPatients()) {
                System.out.println("Patient ID: " + p.getPatientId() + ", Name: " + p.getName());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
