import java.rmi.Remote;
import java.rmi.RemoteException;

public interface CalculationService extends Remote {
    // Method to calculate square
    double calculateSquare(double number) throws RemoteException;

    // Method to calculate cube
    double calculateCube(double number) throws RemoteException;
}
