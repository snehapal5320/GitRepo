import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

public class CalculationServiceImpl extends UnicastRemoteObject implements CalculationService {

    // Constructor to handle remote exceptions
    public CalculationServiceImpl() throws RemoteException {
        super();
    }

    // Implement the square calculation method
    @Override
    public double calculateSquare(double number) throws RemoteException {
        return number * number;
    }

    // Implement the cube calculation method
    @Override
    public double calculateCube(double number) throws RemoteException {
        return number * number * number;
    }

    // Server main method
    public static void main(String[] args) {
        try {
            // Create the remote object
            CalculationServiceImpl service = new CalculationServiceImpl();
            
            // Bind the service to the RMI registry
            java.rmi.registry.LocateRegistry.createRegistry(1099);
            java.rmi.Naming.rebind("CalculationService", service);

            System.out.println("Calculation Service is running...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
