import java.awt.*;
import java.awt.event.*;
import java.rmi.Naming;
import javax.swing.*;

public class CalculationClient extends JFrame {

    private JTextField numberField;
    private JTextField squareField;
    private JTextField cubeField;
    private CalculationService calculationService;

    public CalculationClient() {
        try {
            // Lookup the remote object in the RMI registry
            calculationService = (CalculationService) Naming.lookup("rmi://localhost/CalculationService");

            // Create the GUI components
            numberField = new JTextField(10);
            squareField = new JTextField(10);
            cubeField = new JTextField(10);
            squareField.setEditable(false);
            cubeField.setEditable(false);
            
            // Create Buttons
            JButton calculateButton = new JButton("Calculate");
            calculateButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    calculate();
                }
            });

            // Layout the components
            setLayout(new FlowLayout());
            add(new JLabel("Enter a number:"));
            add(numberField);
            add(calculateButton);
            add(new JLabel("Square:"));
            add(squareField);
            add(new JLabel("Cube:"));
            add(cubeField);

            // Window settings
            setTitle("Square and Cube Calculator");
            setSize(300, 200);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setVisible(true);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void calculate() {
        try {
            // Get the number from the user input
            double number = Double.parseDouble(numberField.getText());

            // Use RMI to calculate the square and cube
            double square = calculationService.calculateSquare(number);
            double cube = calculationService.calculateCube(number);

            // Display the results in the text fields
            squareField.setText(String.valueOf(square));
            cubeField.setText(String.valueOf(cube));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        // Run the client GUI
        new CalculationClient();
    }
}
