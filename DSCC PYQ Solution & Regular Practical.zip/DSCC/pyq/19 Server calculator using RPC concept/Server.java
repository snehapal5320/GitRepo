import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class Server {
    public static void main(String[] args) {
        try {
            // Start the RMI registry on port 1099
            LocateRegistry.createRegistry(1099);

            // Create an instance of the CalculatorServer
            CalculatorServer calculator = new CalculatorServer();

            // Bind the CalculatorServer instance to a name in the RMI registry
            Naming.rebind("CalculatorService", calculator);

            System.out.println("Calculator Service is running...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

