import java.rmi.Naming;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try {
            // Lookup the CalculatorService in the RMI registry
            Calculator calculator = (Calculator) Naming.lookup("CalculatorService");

            Scanner scanner = new Scanner(System.in);

            System.out.println("Welcome to the RPC Calculator!");
            System.out.print("Enter first number: ");
            int num1 = scanner.nextInt();

            System.out.print("Enter second number: ");
            int num2 = scanner.nextInt();

            System.out.println("Choose an operation: ");
            System.out.println("1. Add\n2. Subtract\n3. Multiply\n4. Divide");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1 -> System.out.println("Result: " + calculator.add(num1, num2));
                case 2 -> System.out.println("Result: " + calculator.subtract(num1, num2));
                case 3 -> System.out.println("Result: " + calculator.multiply(num1, num2));
                case 4 -> {
                    try {
                        System.out.println("Result: " + calculator.divide(num1, num2));
                    } catch (ArithmeticException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                }
                default -> System.out.println("Invalid choice!");
            }

            scanner.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
