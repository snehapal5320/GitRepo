import java.io.*;
import java.net.*;
import java.util.Scanner;

public class PrimeClient {
    public static void main(String[] args) {
        String host = "localhost"; // Server hostname or IP
        int port = 5000;          // Server port

        try (Socket socket = new Socket(host, port);
             BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter output = new PrintWriter(socket.getOutputStream(), true)) {

            System.out.println("Connected to Prime Server.");

            // Read number from the user
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter a number to check if it is prime: ");
            int number = scanner.nextInt();

            // Send the number to the server
            output.println(number);

            // Receive and print the response from the server
            String response = input.readLine();
            System.out.println("Server response: " + response);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
