import java.io.*;
import java.net.*;

public class PrimeServer {
    public static void main(String[] args) {
        int port = 5000; // Server port
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Prime Server is running on port " + port + "...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Connected to client: " + clientSocket.getInetAddress());

                // Handle client request
                try (BufferedReader input = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                     PrintWriter output = new PrintWriter(clientSocket.getOutputStream(), true)) {

                    // Read the number from the client
                    String message = input.readLine();
                    int number = Integer.parseInt(message);
                    System.out.println("Received number: " + number);

                    // Check if the number is prime
                    boolean isPrime = isPrime(number);
                    String response = isPrime ? number + " is a prime number." : number + " is not a prime number.";

                    // Send the response to the client
                    output.println(response);
                    System.out.println("Response sent: " + response);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to check if a number is prime
    public static boolean isPrime(int num) {
        if (num <= 1) return false;
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) return false;
        }
        return true;
    }
}
