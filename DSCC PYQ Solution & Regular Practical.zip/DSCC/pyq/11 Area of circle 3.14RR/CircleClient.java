import java.rmi.Naming;
import java.util.Scanner;

public class CircleClient {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Look up the remote object in the RMI registry
            CircleService circleService = (CircleService) Naming.lookup("rmi://localhost/CircleService");

            // Get the radius from the user
            System.out.print("Enter the radius of the circle: ");
            double radius = scanner.nextDouble();

            // Call the remote method to calculate the area
            double area = circleService.calculateArea(radius);

            // Output the result
            System.out.println("The area of the circle with radius " + radius + " is: " + area);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
}
