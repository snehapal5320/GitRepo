import java.rmi.Remote;
import java.rmi.RemoteException;

public interface CircleService extends Remote {
    // Method to calculate the area of a circle
    double calculateArea(double radius) throws RemoteException;
}
