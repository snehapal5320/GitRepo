import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class CircleServer {
    public static void main(String[] args) {
        try {
            // Start the RMI registry on the default port 1099
            LocateRegistry.createRegistry(1099);
            System.out.println("RMI registry started...");

            // Create the remote object (service)
            CircleServiceImpl circleService = new CircleServiceImpl();
            
            // Bind the remote object to the RMI registry
            Naming.rebind("rmi://localhost/CircleService", circleService);
            System.out.println("CircleService object bound in registry");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
