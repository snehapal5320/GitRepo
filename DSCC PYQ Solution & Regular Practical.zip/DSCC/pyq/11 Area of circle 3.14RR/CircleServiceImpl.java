import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class CircleServiceImpl extends UnicastRemoteObject implements CircleService {

    // Constructor
    public CircleServiceImpl() throws RemoteException {
        super();
    }

    // Method to calculate the area of a circle
    @Override
    public double calculateArea(double radius) throws RemoteException {
        return 3.14 * radius * radius; // Formula for the area of a circle
    }
}
