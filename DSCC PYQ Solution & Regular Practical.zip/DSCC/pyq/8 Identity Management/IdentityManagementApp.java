import java.util.Scanner;

public class IdentityManagementApp {
    public static void main(String[] args) {
        IdentityManager idManager = new IdentityManager();
        Scanner scanner = new Scanner(System.in);

        // Register some users (you can expand this)
        idManager.registerUser("admin", "admin123", "admin");
        idManager.registerUser("user", "user123", "user");

        // Simulate Login
        System.out.println("Enter username:");
        String username = scanner.nextLine();

        System.out.println("Enter password:");
        String password = scanner.nextLine();

        // Authenticate user
        User authenticatedUser = idManager.authenticateUser(username, password);

        if (authenticatedUser != null) {
            System.out.println("Login successful!");
            System.out.println("Welcome, " + authenticatedUser.getUsername() + "! You are logged in as: " + authenticatedUser.getRole());

            // Simulate accessing a restricted resource (only accessible by 'admin' role)
            idManager.accessRestrictedResource(authenticatedUser);
        } else {
            System.out.println("Authentication failed. Please try again.");
        }

        scanner.close();
    }
}
