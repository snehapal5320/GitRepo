import java.util.*;

public class IdentityManager {
    private Map<String, User> users = new HashMap<>();
    
    // Method to register a new user
    public void registerUser(String username, String password, String role) {
        if (users.containsKey(username)) {
            System.out.println("Username already exists!");
        } else {
            users.put(username, new User(username, password, role));
            System.out.println("User registered successfully!");
        }
    }

    // Method to authenticate a user
    public User authenticateUser(String username, String password) {
        User user = users.get(username);
        if (user != null && user.getPassword().equals(password)) {
            return user; // User authenticated successfully
        } else {
            System.out.println("Invalid credentials!");
            return null; // Authentication failed
        }
    }

    // Method to authorize user based on role
    public boolean authorizeUser(User user, String requiredRole) {
        if (user != null && user.getRole().equals(requiredRole)) {
            return true; // User has the required role
        } else {
            System.out.println("Access Denied! Insufficient permissions.");
            return false; // User does not have required role
        }
    }

    // Method to simulate a restricted resource access
    public void accessRestrictedResource(User user) {
        if (authorizeUser(user, "admin")) {
            System.out.println("Accessing restricted resource...");
        }
    }
}
